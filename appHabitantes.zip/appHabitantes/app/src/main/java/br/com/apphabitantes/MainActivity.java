package br.com.apphabitantes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Objetos para guardar os dados
    List<Habitante> habitantes = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        habitantes = new ArrayList<Habitante>();

        // Deve vincular a um botão a execução dos métodos de leitura e cadastro
        
    }

    private void leitura()
    {
        // Deve ler os componentes da tela

    }

    private void cadastra(Habitante habitante)
    {
        habitantes.add(habitante);
    }

}