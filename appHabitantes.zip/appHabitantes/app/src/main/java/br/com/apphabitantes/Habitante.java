package br.com.apphabitantes;

public class Habitante {
    private String nome;
    private String rg;
    private String sexo;
    private String dataNasc;

    // Construct
    public Habitante(String nome, String rg, String sexo, String dataNasc) {
        this.nome = nome;
        this.rg = rg;
        this.sexo = sexo;
        this.dataNasc = dataNasc;
    }

    // Setters
    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public void setDataNasc(String dataNasc) {
        this.dataNasc = dataNasc;
    }

    // Geters
    public String getNome() {
        return nome;
    }

    public String getRg() {
        return rg;
    }

    public String getSexo() {
        return sexo;
    }

    public String getDataNasc() {
        return dataNasc;
    }
}
